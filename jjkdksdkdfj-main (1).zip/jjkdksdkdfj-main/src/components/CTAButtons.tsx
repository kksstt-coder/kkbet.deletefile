import { Download, MessageCircle } from "lucide-react";

interface CTAButtonsProps {
  primaryText?: string;
  secondaryText?: string;
  onPrimaryClick?: () => void;
  onSecondaryClick?: () => void;
}

const CTAButtons = ({
  primaryText = "Register Now",
  secondaryText = "Contact Us",
  onPrimaryClick,
  onSecondaryClick,
}: CTAButtonsProps) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 md:hidden safe-x">
      {/* Gradient backdrop with blur */}
      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/98 to-transparent backdrop-blur-xl" />
      
      {/* Top decorative line */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent" />
      
      {/* Buttons container with safe area */}
      <div className="relative container mx-auto px-4 pt-4 pb-4 flex gap-3" style={{ paddingBottom: 'max(1rem, env(safe-area-inset-bottom))' }}>
        {/* Primary CTA Button - Large touch target */}
        <button
          onClick={onPrimaryClick}
          className="flex-1 relative group overflow-hidden rounded-xl shadow-gold touch-target no-select active:scale-[0.97] transition-transform duration-150"
        >
          {/* Animated gradient background */}
          <div className="absolute inset-0 bg-gradient-to-r from-primary via-secondary to-primary bg-[length:200%_100%] animate-gradient rounded-xl" />
          
          {/* Button content */}
          <div className="relative flex items-center justify-center gap-2 py-4 min-h-[52px] font-display font-bold text-background animate-pulse-glow rounded-xl">
            <Download className="w-5 h-5" />
            <span className="text-sm">{primaryText}</span>
          </div>
        </button>

        {/* Secondary CTA Button */}
        <button
          onClick={onSecondaryClick}
          className="flex-1 relative group overflow-hidden rounded-xl glass-card border border-primary/40 active:border-primary transition-all duration-150 touch-target no-select active:scale-[0.97]"
        >
          {/* Button content */}
          <div className="relative flex items-center justify-center gap-2 py-4 min-h-[52px] font-display font-semibold text-primary">
            <MessageCircle className="w-5 h-5" />
            <span className="text-sm">{secondaryText}</span>
          </div>
        </button>
      </div>
    </div>
  );
};

export default CTAButtons;
