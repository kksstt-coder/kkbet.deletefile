import { Download, MessageCircle, Shield, Gift, Star, Zap } from "lucide-react";

interface DesktopCTAProps {
  primaryText?: string;
  secondaryText?: string;
  onPrimaryClick?: () => void;
  onSecondaryClick?: () => void;
}

const DesktopCTA = ({
  primaryText = "Start Playing Now",
  secondaryText = "Contact Support",
  onPrimaryClick,
  onSecondaryClick,
}: DesktopCTAProps) => {
  return (
    <section className="hidden md:block py-20 lg:py-32 relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[1000px] h-[600px] bg-gradient-radial from-primary/10 via-primary/3 to-transparent blur-3xl" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        {/* CTA Card */}
        <div className="glass-card rounded-3xl p-10 lg:p-16 border border-primary/15 text-center relative overflow-hidden">
          {/* Top shine line */}
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent" />
          
          <div className="relative z-10">
            {/* Icon */}
            <div className="relative w-20 h-20 lg:w-24 lg:h-24 mx-auto mb-6 lg:mb-8">
              <div className="absolute inset-0 bg-primary/20 rounded-2xl blur-xl animate-glow-soft" />
              <div className="relative w-full h-full rounded-2xl lg:rounded-3xl bg-gradient-to-br from-primary via-secondary to-accent flex items-center justify-center shadow-gold animate-pulse-glow">
                <Gift className="w-10 h-10 lg:w-12 lg:h-12 text-background" />
              </div>
            </div>

            {/* Headline */}
            <h2 className="font-display text-3xl lg:text-4xl xl:text-5xl font-bold mb-4 lg:mb-6">
              <span className="text-gradient-gold">Ready to Win Big?</span>
            </h2>

            <p className="text-foreground/50 max-w-xl mx-auto mb-8 lg:mb-10 text-base lg:text-lg leading-relaxed">
              Join thousands of winners today. Get exclusive bonuses and start your premium gaming journey.
            </p>

            {/* Features */}
            <div className="flex flex-wrap justify-center gap-4 lg:gap-8 mb-10 lg:mb-12">
              {[
                { icon: Shield, label: "Secure" },
                { icon: Gift, label: "Bonus" },
                { icon: Star, label: "VIP" },
                { icon: Zap, label: "Fast" },
              ].map((feature) => (
                <div key={feature.label} className="flex items-center gap-2 text-foreground/60">
                  <div className="w-7 h-7 lg:w-8 lg:h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                    <feature.icon className="w-3.5 h-3.5 lg:w-4 lg:h-4 text-primary" />
                  </div>
                  <span className="text-xs lg:text-sm font-medium">{feature.label}</span>
                </div>
              ))}
            </div>

            {/* Buttons */}
            <div className="flex justify-center gap-4">
              {/* Primary Button */}
              <button
                onClick={onPrimaryClick}
                className="relative group overflow-hidden rounded-xl lg:rounded-2xl touch-target"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-primary via-secondary to-primary bg-[length:200%_100%] animate-gradient" />
                <div className="relative flex items-center gap-2 lg:gap-3 py-4 lg:py-5 px-8 lg:px-12 font-display font-bold text-background text-sm lg:text-lg">
                  <Download className="w-4 h-4 lg:w-5 lg:h-5" />
                  <span>{primaryText}</span>
                </div>
              </button>

              {/* Secondary Button */}
              <button
                onClick={onSecondaryClick}
                className="group rounded-xl lg:rounded-2xl glass-card border border-primary/30 hover:border-primary/60 transition-all duration-300 touch-target"
              >
                <div className="flex items-center gap-2 lg:gap-3 py-4 lg:py-5 px-8 lg:px-12 font-display font-semibold text-primary text-sm lg:text-lg">
                  <MessageCircle className="w-4 h-4 lg:w-5 lg:h-5" />
                  <span>{secondaryText}</span>
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DesktopCTA;
