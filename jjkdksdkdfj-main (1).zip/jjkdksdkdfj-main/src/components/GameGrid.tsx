import GameCard from "./GameCard";
import { Gamepad2, ChevronRight } from "lucide-react";

interface Game {
  id: string;
  title: string;
  image: string;
  category: string;
  isHot?: boolean;
}

interface GameGridProps {
  title?: string;
  subtitle?: string;
  games?: Game[];
}

const defaultGames: Game[] = [
  {
    id: "1",
    title: "Lucky Slots",
    image: "https://images.unsplash.com/photo-1596838132731-3301c3fd4317?w=400&h=300&fit=crop",
    category: "Slots",
    isHot: true,
  },
  {
    id: "2",
    title: "Royal Baccarat",
    image: "https://images.unsplash.com/photo-1511193311914-0346f16efe90?w=400&h=300&fit=crop",
    category: "Table Games",
    isHot: false,
  },
  {
    id: "3",
    title: "Ocean Treasure",
    image: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=400&h=300&fit=crop",
    category: "Fish Games",
    isHot: true,
  },
  {
    id: "4",
    title: "Poker Championship",
    image: "https://images.unsplash.com/photo-1541278107931-e006523892df?w=400&h=300&fit=crop",
    category: "Cards",
    isHot: false,
  },
  {
    id: "5",
    title: "Golden Wheel",
    image: "https://images.unsplash.com/photo-1606167668584-78701c57f13d?w=400&h=300&fit=crop",
    category: "Wheel",
    isHot: true,
  },
  {
    id: "6",
    title: "Dice Royale",
    image: "https://images.unsplash.com/photo-1522069213448-443a614da9b6?w=400&h=300&fit=crop",
    category: "Dice",
    isHot: false,
  },
];

const GameGrid = ({
  title = "Popular Games",
  subtitle = "Explore our collection of premium games",
  games = defaultGames,
}: GameGridProps) => {
  return (
    <section id="games" className="py-12 md:py-24 lg:py-32 relative">
      {/* Background - Simplified for mobile */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-[800px] h-[300px] bg-gradient-radial from-primary/6 to-transparent blur-2xl" />
      </div>

      <div className="container mx-auto px-4 relative z-10 safe-x">
        {/* Section Header - Compact on mobile */}
        <div className="text-center mb-8 md:mb-16">
          <div className="inline-flex items-center gap-2 badge-luxury mb-4 md:mb-6">
            <Gamepad2 className="w-3.5 h-3.5 md:w-4 md:h-4 text-primary" />
            <span className="text-xs md:text-sm font-medium text-primary tracking-wide">Featured Games</span>
          </div>
          
          <h2 className="font-display text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-3 md:mb-6">
            <span className="text-gradient-gold">{title}</span>
          </h2>
          
          <p className="text-foreground/50 max-w-md mx-auto text-sm md:text-base lg:text-lg leading-relaxed">
            {subtitle}
          </p>
        </div>

        {/* Games Grid - Optimized gaps for mobile */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 md:gap-5 lg:gap-8">
          {games.map((game, index) => (
            <div
              key={game.id}
              className="animate-fade-in-up"
              style={{ animationDelay: `${index * 0.08}s` }}
            >
              <GameCard
                title={game.title}
                image={game.image}
                category={game.category}
                isHot={game.isHot}
                onClick={() => console.log(`Clicked on ${game.title}`)}
              />
            </div>
          ))}
        </div>

        {/* View All Button - Touch friendly */}
        <div className="text-center mt-8 md:mt-14">
          <button className="group inline-flex items-center gap-2 md:gap-3 px-6 md:px-8 py-3 md:py-4 glass-card active:border-primary/40 md:hover:border-primary/40 rounded-xl md:rounded-2xl text-foreground font-medium transition-all duration-300 touch-target no-select active:scale-[0.98]">
            <span className="text-sm tracking-wide">View All Games</span>
            <ChevronRight className="w-4 h-4 text-primary" />
          </button>
        </div>
      </div>
    </section>
  );
};

export default GameGrid;
