import { useState } from "react";

interface FeatureSectionProps {
  src: string;
  alt?: string;
  link?: string;
  type?: "image" | "video";
}

const FeatureSection = ({
  src = "/placeholder.svg",
  alt = "Featured content",
  link,
  type = "image",
}: FeatureSectionProps) => {
  const [isLoaded, setIsLoaded] = useState(false);

  const handleClick = () => {
    if (link) {
      if (link.startsWith("http")) {
        window.open(link, "_blank", "noopener,noreferrer");
      } else {
        window.location.href = link;
      }
    }
  };

  const isVideo = type === "video" || src.endsWith(".mp4") || src.endsWith(".webm");

  return (
    <section className="relative w-full">
      
      {/* Full-width feature media container - no cropping */}
      <div
        onClick={link ? handleClick : undefined}
        role={link ? "link" : undefined}
        tabIndex={link ? 0 : undefined}
        onKeyDown={(e) => {
          if (link && (e.key === "Enter" || e.key === " ")) {
            handleClick();
          }
        }}
        className={`
          relative w-full
          ${link ? "cursor-pointer" : ""}
        `}
      >
        {/* Loading skeleton */}
        {!isLoaded && (
          <div className="w-full aspect-video bg-gradient-to-br from-primary/5 via-card to-primary/10 animate-pulse" />
        )}
        
        {/* Feature Media - Full visible, aspect ratio preserved */}
        {isVideo ? (
          <video
            src={src}
            className={`
              w-full h-auto block max-w-full
              transition-opacity duration-700 ease-out
              ${isLoaded ? "opacity-100" : "opacity-0"}
            `}
            style={{ objectFit: 'contain', objectPosition: 'center', overflow: 'visible' }}
            onLoadedData={() => setIsLoaded(true)}
            autoPlay
            loop
            muted
            playsInline
          />
        ) : (
          <img
            src={src}
            alt={alt}
            className={`
              w-full h-auto block max-w-full
              transition-opacity duration-700 ease-out
              ${isLoaded ? "opacity-100" : "opacity-0"}
            `}
            style={{ objectFit: 'contain', objectPosition: 'center', overflow: 'visible' }}
            onLoad={() => setIsLoaded(true)}
            loading="lazy"
          />
        )}
        
        {/* Bottom gradient fade for smooth transition to next section */}
        <div className="absolute bottom-0 left-0 right-0 h-24 md:h-32 bg-gradient-to-t from-background via-background/80 to-transparent z-10 pointer-events-none" />
      </div>
    </section>
  );
};

export default FeatureSection;
