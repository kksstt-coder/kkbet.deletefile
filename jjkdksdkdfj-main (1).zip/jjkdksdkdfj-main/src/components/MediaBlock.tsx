import { useState, useRef } from "react";

interface MediaBlockProps {
  src: string;
  alt?: string;
  type?: "image" | "video";
  link?: string;
  className?: string;
}

const MediaBlock = ({
  src,
  alt = "Media content",
  type = "image",
  link,
  className = "",
}: MediaBlockProps) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  const handleClick = () => {
    if (link) {
      if (link.startsWith("http")) {
        window.open(link, "_blank", "noopener,noreferrer");
      } else {
        window.location.href = link;
      }
    }
  };

  const content = type === "video" ? (
    <video
      ref={videoRef}
      src={src}
      autoPlay
      loop
      muted
      playsInline
      className={`w-full h-full object-cover transition-opacity duration-500 ${isLoaded ? "opacity-100" : "opacity-0"}`}
      onLoadedData={() => setIsLoaded(true)}
    />
  ) : (
    <img
      src={src}
      alt={alt}
      className={`w-full h-full object-cover transition-opacity duration-500 ${isLoaded ? "opacity-100" : "opacity-0"}`}
      onLoad={() => setIsLoaded(true)}
      loading="lazy"
    />
  );

  return (
    <div
      onClick={link ? handleClick : undefined}
      className={`
        relative overflow-hidden rounded-xl md:rounded-2xl
        bg-gradient-to-br from-card/80 to-card/40
        border border-primary/10
        shadow-lg shadow-black/20
        aspect-video
        ${link ? "cursor-pointer active:scale-[0.98] transition-transform duration-150" : ""}
        ${className}
      `}
    >
      {/* Loading skeleton */}
      {!isLoaded && (
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-primary/10 animate-pulse" />
      )}
      
      {/* Media content */}
      {content}
      
      {/* Subtle shine overlay */}
      <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-transparent pointer-events-none" />
    </div>
  );
};

export default MediaBlock;
