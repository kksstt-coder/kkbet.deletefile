import heroCharacter from "@/assets/hero-character.png";

interface HeroSectionProps {
  heroImage?: string;
  heroLink?: string;
  heroAlt?: string;
}

const HeroSection = ({
  heroImage = heroCharacter,
  heroLink = "",
  heroAlt = "Premium gaming hero",
}: HeroSectionProps) => {
  const handleHeroClick = () => {
    if (heroLink) {
      if (heroLink.startsWith("http")) {
        window.open(heroLink, "_blank", "noopener,noreferrer");
      } else {
        window.location.href = heroLink;
      }
    }
  };

  return (
    <section className="relative w-full pt-[60px] md:pt-[72px]" style={{ zIndex: 1 }}>
      {/* Main Hero Image - Full visible, no cropping */}
      <div 
        className={`
          relative w-full
          ${heroLink ? "cursor-pointer" : ""}
        `}
        onClick={heroLink ? handleHeroClick : undefined}
        role={heroLink ? "link" : undefined}
        tabIndex={heroLink ? 0 : undefined}
        onKeyDown={(e) => {
          if (heroLink && (e.key === "Enter" || e.key === " ")) {
            handleHeroClick();
          }
        }}
      >
        {/* Hero Image - Full Width, fully visible, aspect ratio preserved */}
        <img
          src={heroImage}
          alt={heroAlt}
          className="w-full h-auto block max-w-full"
          style={{ objectFit: 'contain', objectPosition: 'center', overflow: 'visible', filter: 'contrast(1.05) saturate(1.08)', imageRendering: 'auto' }}
          loading="eager"
          fetchPriority="high"
        />
        
      </div>
    </section>
  );
};

export default HeroSection;
