import { Play } from "lucide-react";

interface GameCardProps {
  title: string;
  image: string;
  category?: string;
  isHot?: boolean;
  onClick?: () => void;
}

const GameCard = ({ 
  title, 
  image, 
  category = "Popular",
  isHot = false,
  onClick 
}: GameCardProps) => {
  return (
    <button
      onClick={onClick}
      className="glass-card group rounded-xl md:rounded-2xl overflow-hidden border border-border/20 active:border-primary/40 md:hover:border-primary/40 transition-all duration-300 w-full text-left touch-target no-select active:scale-[0.98] md:active:scale-100"
    >
      {/* Image Container - Optimized aspect ratio for mobile */}
      <div className="relative aspect-[4/3] overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-500 md:group-hover:scale-110"
          loading="lazy"
        />
        
        {/* Gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent opacity-70" />
        
        {/* Hot badge - Smaller on mobile */}
        {isHot && (
          <div className="absolute top-2 right-2 md:top-3 md:right-3 px-2 py-1 bg-gradient-to-r from-accent via-primary to-accent bg-[length:200%_100%] text-background text-[10px] md:text-xs font-bold rounded-full shadow-lg">
            🔥 HOT
          </div>
        )}
        
        {/* Category badge - Compact on mobile */}
        <div className="absolute top-2 left-2 md:top-3 md:left-3 px-2 py-1 rounded-full bg-background/60 backdrop-blur-sm border border-border/30 text-[10px] md:text-xs">
          <span className="text-primary/90">{category}</span>
        </div>
        
        {/* Play button - Only on desktop hover */}
        <div className="absolute inset-0 hidden md:flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300">
          <div className="w-14 h-14 rounded-full bg-primary/90 backdrop-blur-sm flex items-center justify-center shadow-gold transform scale-75 group-hover:scale-100 transition-transform duration-300">
            <Play className="w-6 h-6 text-background fill-current ml-1" />
          </div>
        </div>
      </div>

      {/* Content - Compact padding on mobile */}
      <div className="p-3 md:p-5">
        <h3 className="font-display font-semibold text-foreground text-xs md:text-sm lg:text-base truncate">
          {title}
        </h3>
        
        {/* Play indicator - Smaller on mobile */}
        <div className="mt-2 md:mt-3 flex items-center gap-1.5 md:gap-2 text-muted-foreground">
          <span className="relative flex h-1.5 w-1.5 md:h-2 md:w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
            <span className="relative inline-flex rounded-full h-full w-full bg-primary"></span>
          </span>
          <span className="text-[10px] md:text-xs tracking-wide">Play Now</span>
        </div>
      </div>
    </button>
  );
};

export default GameCard;
