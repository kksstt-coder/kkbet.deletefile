import { useState, useEffect } from "react";
import { Menu, X, Crown, Sparkles } from "lucide-react";

interface HeaderProps {
  logoText?: string;
}

const Header = ({ logoText = "ROYAL PLAY" }: HeaderProps) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Prevent body scroll when mobile menu is open
  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isMobileMenuOpen]);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-[100] transition-all duration-300 safe-top ${
        isScrolled
          ? "glass-card border-b border-primary/10"
          : "bg-transparent"
      }`}
    >
      <div className="container mx-auto px-4 py-3 md:py-4 flex items-center justify-between safe-x">
        {/* Logo */}
        <div className="flex items-center gap-2 md:gap-3">
          <div className="relative">
            <div className="absolute inset-0 bg-primary/30 rounded-full blur-lg animate-glow-soft" />
            <div className="relative w-10 h-10 md:w-12 md:h-12 rounded-full bg-gradient-to-br from-primary via-secondary to-accent flex items-center justify-center shadow-gold">
              <Crown className="w-5 h-5 md:w-6 md:h-6 text-background" />
            </div>
          </div>
          <div className="flex flex-col">
            <span className="font-display font-bold text-lg md:text-xl text-gradient-gold tracking-wider">
              {logoText}
            </span>
            <span className="text-[9px] md:text-[10px] text-muted-foreground tracking-[0.2em] md:tracking-[0.3em] uppercase hidden sm:block">
              Premium Gaming
            </span>
          </div>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          {["Games", "Promotions", "VIP Club", "Support"].map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase().replace(" ", "-")}`}
              className="relative text-foreground/70 hover:text-primary transition-all duration-300 text-sm font-medium group"
            >
              <span className="relative z-10">{item}</span>
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-primary to-accent group-hover:w-full transition-all duration-300" />
            </a>
          ))}
        </nav>

        {/* Desktop CTA */}
        <div className="hidden md:flex items-center gap-3">
          <button className="px-5 py-2.5 rounded-xl text-sm font-medium text-foreground/80 hover:text-primary transition-colors touch-target">
            Login
          </button>
          <button className="relative group overflow-hidden px-5 py-2.5 rounded-xl font-medium text-sm touch-target">
            <div className="absolute inset-0 bg-gradient-to-r from-primary via-secondary to-primary bg-[length:200%_100%] animate-gradient rounded-xl" />
            <span className="relative flex items-center gap-2 text-background">
              <Sparkles className="w-4 h-4" />
              Join Now
            </span>
          </button>
        </div>

        {/* Mobile Menu Button - Larger touch target */}
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="md:hidden w-12 h-12 flex items-center justify-center rounded-xl glass-card border border-primary/20 text-foreground active:scale-90 active:bg-primary/20 transition-all duration-150 touch-target no-select"
          aria-label="Toggle menu"
        >
          {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile Menu - Full screen overlay */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 top-[60px] glass-card border-t border-primary/10 animate-fade-in-up overflow-y-auto safe-bottom">
          <nav className="container mx-auto px-4 py-6 flex flex-col gap-2 safe-x">
            {["Games", "Promotions", "VIP Club", "Support"].map((item, index) => (
              <a
                key={item}
                href={`#${item.toLowerCase().replace(" ", "-")}`}
                onClick={() => setIsMobileMenuOpen(false)}
                className="text-foreground/80 hover:text-primary active:bg-primary/10 transition-colors py-4 px-4 text-center text-lg font-medium rounded-xl touch-target no-select"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                {item}
              </a>
            ))}
            <div className="mt-6 pt-6 border-t border-border/30 flex flex-col gap-3">
              <button className="py-4 rounded-xl font-medium text-foreground/80 border border-border/30 active:border-primary/30 transition-colors touch-target no-select">
                Login
              </button>
              <button className="relative overflow-hidden py-4 rounded-xl font-medium touch-target no-select active:scale-[0.98] transition-transform">
                <div className="absolute inset-0 bg-gradient-to-r from-primary to-secondary" />
                <span className="relative text-background font-semibold">Join Now</span>
              </button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
