import { Crown, Shield, CreditCard, Clock } from "lucide-react";

interface FooterProps {
  logoText?: string;
  copyrightText?: string;
}

const Footer = ({
  logoText = "ROYAL PLAY",
  copyrightText = "© 2025 Royal Play. All rights reserved.",
}: FooterProps) => {
  return (
    <footer className="relative py-12 md:py-16 lg:py-20 mb-28 md:mb-0 overflow-hidden safe-x">
      {/* Background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-gradient-radial from-primary/5 to-transparent blur-2xl" />
      </div>
      
      {/* Top border */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
      
      <div className="container mx-auto px-4 relative z-10">
        {/* Trust badges - Horizontal scroll on mobile */}
        <div className="flex justify-center gap-4 md:gap-8 lg:gap-10 mb-8 md:mb-12 lg:mb-16 overflow-x-auto pb-2 -mx-4 px-4 scrollbar-hide">
          {[
            { icon: Shield, label: "Secure" },
            { icon: CreditCard, label: "Safe Pay" },
            { icon: Clock, label: "24/7" },
          ].map((badge) => (
            <div key={badge.label} className="flex items-center gap-1.5 md:gap-2 text-foreground/40 whitespace-nowrap">
              <badge.icon className="w-3.5 h-3.5 md:w-4 md:h-4 text-primary/60" />
              <span className="text-xs md:text-sm tracking-wide">{badge.label}</span>
            </div>
          ))}
        </div>
        
        {/* Divider */}
        <div className="section-divider mb-8 md:mb-12 lg:mb-16" />
        
        <div className="flex flex-col items-center gap-6 md:flex-row md:justify-between md:gap-8">
          {/* Logo */}
          <div className="flex items-center gap-2 md:gap-3">
            <div className="relative">
              <div className="absolute inset-0 bg-primary/20 rounded-full blur-lg" />
              <div className="relative w-9 h-9 md:w-10 md:h-10 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
                <Crown className="w-4 h-4 md:w-5 md:h-5 text-background" />
              </div>
            </div>
            <div className="flex flex-col">
              <span className="font-display font-bold text-base md:text-lg text-gradient-gold">
                {logoText}
              </span>
              <span className="text-[9px] md:text-[10px] text-muted-foreground tracking-widest uppercase">
                Premium Gaming
              </span>
            </div>
          </div>

          {/* Links - Horizontal on mobile */}
          <div className="flex gap-6 md:gap-8 text-sm">
            {["Terms", "Privacy", "Support"].map((link) => (
              <a 
                key={link}
                href="#" 
                className="text-foreground/40 active:text-primary md:hover:text-primary transition-colors duration-300 tracking-wide touch-target py-2"
              >
                {link}
              </a>
            ))}
          </div>

          {/* Copyright */}
          <p className="text-foreground/30 text-xs md:text-sm text-center">
            {copyrightText}
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
