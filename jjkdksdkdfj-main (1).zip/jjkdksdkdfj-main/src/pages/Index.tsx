import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import heroBanner from "@/assets/hero-banner.jpg";
import FeatureSection from "@/components/FeatureSection";
import featureVideo from "@/assets/feature-video.mp4";
import GameGrid from "@/components/GameGrid";
import DesktopCTA from "@/components/DesktopCTA";
import CTAButtons from "@/components/CTAButtons";
import Footer from "@/components/Footer";

const Index = () => {
  const handleRegister = () => {
    console.log("Register clicked");
    // Add your registration logic here
  };

  const handleContact = () => {
    console.log("Contact clicked");
    // Add your contact logic here
  };

  return (
    <div className="min-h-screen bg-background overflow-x-hidden scroll-smooth-touch">
      {/* Sticky Header */}
      <Header logoText="ROYAL PLAY" />

      {/* Hero Section */}
      <HeroSection
        heroImage={heroBanner}
        heroLink=""
        heroAlt="GKK99 Premium Gaming Banner"
      />

      {/* Feature Section - Full-screen immersive media */}
      <FeatureSection
        src={featureVideo}
        alt="Featured promotion"
        link=""
        type="video"
      />

      {/* Game Grid Section */}
      <GameGrid
        title="Popular Games"
        subtitle="Explore our collection of premium games with the best odds"
      />

      {/* Desktop CTA Section */}
      <DesktopCTA
        primaryText="Start Playing Now"
        secondaryText="Contact Support"
        onPrimaryClick={handleRegister}
        onSecondaryClick={handleContact}
      />

      {/* Footer */}
      <Footer
        logoText="ROYAL PLAY"
        copyrightText="© 2025 Royal Play. All rights reserved."
      />

      {/* Mobile Fixed CTA Buttons */}
      <CTAButtons
        primaryText="Register Now"
        secondaryText="Contact Us"
        onPrimaryClick={handleRegister}
        onSecondaryClick={handleContact}
      />
    </div>
  );
};

export default Index;
